# EOFError (Ejemplo 2)

## Objetivo de Aprendizaje

- ✅ Comprender qué es un `EOFError`, por qué ocurre y cómo manejarlo.

---

## Errores de Fin de Archivo

### ¿Qué es un EOFError?

Un **EOFError** ocurre en Python cuando el programa intenta leer entrada, pero se **alcanza el final del archivo (EOF) o flujo de entrada inesperadamente**. Esto típicamente sucede cuando se usa `input()` y no hay más datos disponibles.

### Cómo Manejar EOFError

#### 1. Usando try-except para capturar EOFError

Un enfoque común es manejar EOFError usando un bloque `try-except`:

```python
try:
    entrada_usuario = input("Ingresa tu nombre: ")
    print("Hola,", entrada_usuario)
except EOFError:
    print("\nEOFError: No se recibió entrada. Saliendo del programa.")
```

**Sin embargo**, asumiendo que la entrada es correcta, ¡no solucionará la raíz del problema! Eso significa que en algún punto estamos leyendo entrada incorrectamente.

#### Cosas a buscar en el resto de tu código

Algunas cosas a tener en cuenta cuando encuentres este error:

```python
bienvenida = input("¡Bienvenido a mi programa!")
# ¿Deberíamos estar obteniendo entrada aquí?
while True:
  print("Selecciona una opción:")
  ...
  opcion = input("¿Qué opción eliges? ('done' para terminar):")
  if opcion == "done":
    # ¿Esto siempre capturará el comando done?
    break
  ...
```

Notando estos problemas podemos corregirlos de la siguiente manera:

```python
print("¡Bienvenido a mi programa!")
while True:
  print("Selecciona una opción:")
  ...
  opcion = input("¿Qué opción eliges? ('done' para terminar):")
  if opcion.lower() == "done":
    break
  ...
```

**Si todo lo demás falla**, ¡intenta imprimir tu entrada y ver exactamente qué estás obteniendo y cuándo lo estás obteniendo!

```python
print("¡Bienvenido a mi programa!")
while True:
  print("Selecciona una opción:")
  ...
  opcion = input("¿Qué opción eliges? ('done' para terminar):")
  print(opcion)
  # ¡Ups, resulta que las instrucciones decían "-1" para terminar!
  # Yo pensé que era "done"
  if opcion.lower() == "done":
    # Esto debería entonces convertirse en [if opcion == "-1":]
    break
  ...
```

**Aborda el problema raíz de este error.**

---

### ¿Cómo Prevenir Errores EOF?

- **Asegura que la entrada esté disponible** antes de leer.
- Usa **depuración con print** y **¡revisa cada llamada a input!**
- **Lee archivos cuidadosamente**, asegurando que los bucles terminen en EOF.

Al implementar estas estrategias, los programas de Python pueden **manejar escenarios EOF elegantemente y evitar bloqueos.**

---

## Pregunta

Crea un script de Python en **`eof.py`** que:

1. **Solicite** al usuario texto con exactamente la cadena

   ```python
   "Input text: "
   ```

2. **Lea** lo que el usuario escriba.

3. **Si el usuario ingresa una línea de texto**, devuelve esa línea (imprímela sin cambios).

4. **Si el usuario no proporciona entrada**, imprime exactamente:

   ```python
   "Eerie silence..."
   ```

{Check It!|assessment}(code-output-compare-664675982)
