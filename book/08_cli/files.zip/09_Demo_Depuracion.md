# Demo de Depuración

## Parte 1: Depurando Manejo de Excepciones

Aunque ya sabes cómo usar `try-except`, es fácil introducir errores sutiles. Exploremos algunos comunes.

---

### Error #1 — Capturando la Excepción Incorrecta

**Código con Problema:**

```python
try:
    num = int(input("Ingresa un número: "))
except TypeError:
    print("¡Eso no era un número!")
```

**¿Qué está mal?**

- El error es que `int(input())` no lanza un `TypeError`. Lanza un `ValueError` cuando la entrada no puede convertirse.

**Solución:**

```python
try:
    num = int(input("Ingresa un número: "))
except ValueError:
    print("¡Eso no era un número!")
```

**Consejo de Depuración:**
Siempre verifica *qué tipo* de error Python realmente lanza. Usa pequeños fragmentos de prueba y lee los mensajes de error cuidadosamente.

---

### Error #2 — Ocultando Todos los Errores

**Código con Problema:**

```python
try:
    print(10 / 0)
except:
    print("¡Algo salió mal!")
```

**¿Qué está mal?**

- El `except:` genérico oculta todos los posibles errores, incluso los serios.
- Es difícil saber qué realmente salió mal.

**Solución:**

```python
try:
    print(10 / 0)
except ZeroDivisionError:
    print("¡No puedes dividir por cero!")
```

**Consejo de Depuración:**
Evita declaraciones `except:` vacías — siempre especifica el tipo de error para que no enmascares accidentalmente errores no relacionados.

---

### Error #3 — Excepción en el Lugar Incorrecto

**Código con Problema:**

```python
num = int(input("Ingresa un número: "))
try:
    print(num / 2)
except ValueError:
    print("¡Número inválido!")
```

**¿Qué está mal?**

- La conversión a `int` sucede *antes* del bloque `try`. Si la entrada no es numérica, el programa se bloquea antes de que el error sea capturado.

**Solución:**

```python
try:
    num = int(input("Ingresa un número: "))
    print(num / 2)
except ValueError:
    print("¡Número inválido!")
```

**Consejo de Depuración:**
Pon todo el código que podría lanzar la excepción *dentro* del bloque `try`.

---

## Parte 2: Depurando Entrada por Línea de Comandos

Veamos errores relacionados con argumentos de línea de comandos usando `sys.argv`.

---

### Error #4 — Olvidando Importar `sys`

**Código con Problema:**

```python
filename = sys.argv[1]
print(f"Abriendo {filename}")
```

**¿Qué está mal?**

- El módulo `sys` no está importado, causando `NameError: name 'sys' is not defined`.

**Solución:**

```python
import sys
filename = sys.argv[1]
print(f"Abriendo {filename}")
```

**Consejo de Depuración:**
Cuando uses `sys.argv`, siempre asegúrate de que `import sys` aparezca al principio.

---

### Error #5 — No Verificar la Longitud de Argumentos

**Código con Problema:**

```python
import sys
filename = sys.argv[1]
print(f"Abriendo {filename}")
```

**¿Qué está mal?**

- Si el usuario ejecuta `python script.py` sin argumentos, esto lanza `IndexError: list index out of range`.

**Solución:**

```python
import sys

if len(sys.argv) < 2:
    print("Uso: python script.py <nombre_archivo>")
    sys.exit(1)

filename = sys.argv[1]
print(f"Abriendo {filename}")
```

**Consejo de Depuración:**
Siempre verifica la longitud de `sys.argv` antes de acceder a elementos.

---

## Actividad de Depuración: El Lector de Archivos Roto

### Escenario

Un desarrollador escribió un script de Python llamado `cli_reader.py` que debería:

1. Tomar un nombre de archivo desde la **línea de comandos**
2. Abrir el archivo
3. Leer números línea por línea
4. Imprimir el **promedio**

Desafortunadamente, el script está lleno de **errores** relacionados con manejo de excepciones y entrada de línea de comandos.

---

### El Código Roto (también en cli_reader.py)

```python
filename = sys.argv[0]

try:
    file = open(filename)
    lines = file.readlines()
    numbers = [int(x) for x in lines]
    avg = sum(numbers) / len(numbers)
    print("The average is " + avg)
except:
    print("Something went wrong!")

file.close()
```

---

### Tu Tarea

Depura este programa para que correctamente:

- Importe los módulos necesarios
- Maneje argumentos de línea de comandos faltantes
- Capture los tipos de error correctos
- Evite ocultar excepciones
- Cierre el archivo de forma segura (incluso si ocurre un error)
- Maneje tanto números enteros como flotantes

---

### Pasos para Depurar

1. **Ejecuta el script sin argumentos** y nota el error.
2. **Ejecútalo con un nombre de archivo válido** (como `numbers.txt`) que contenga números — nota cualquier nuevo error.
3. **Corrige un error a la vez** hasta que todos los escenarios de entrada posibles funcionen.
4. **Usa los archivos de entrada de ejemplo y la tabla de abajo** para guiar tu proceso de depuración.

|||guidance
### Ejemplo de una Versión Corregida

```python
import sys
try:
  filename = sys.argv[1]
except IndexError:
  print("Usage: python average_reader.py <filename>")
try:
  file = open(filename)
  lines = file.readlines()
  numbers = [int(x) for x in lines]
  avg = sum(numbers) / len(numbers)
  print(f"The average is {avg:.2f}")
except ValueError:
  print("File contains non-numeric data.")
except ZeroDivisionError:
  print("File is empty.")
except FileNotFoundError:
  print("File not found. Please check the filename.")
file.close()
```
|||

---

### Archivos de Entrada de Ejemplo

Estos archivos están presentes en tu árbol de archivos. Si accidentalmente sobrescribes los datos, simplemente copia el texto correspondiente de vuelta al archivo.

#### Archivo: `numbers.txt`

```plaintext
5
10
15
20
```

#### Archivo: `bad_data.txt`

```plaintext
5
abc
10
```

#### Archivo: `empty.txt`

```plaintext
```

---

### Comandos de Ejemplo y Salidas

| **Comando**                         | **Qué Sucede**                                                       | **Salida Esperada**                          |
| ----------------------------------- | -------------------------------------------------------------------- | -------------------------------------------- |
| `python cli_reader.py numbers.txt`  | ✅ Archivo válido con enteros                                         | `The average is 12.50`                       |
| `python cli_reader.py bad_data.txt` | ❌ Datos no numéricos causan `ValueError`                             | `File contains non-numeric data.`            |
| `python cli_reader.py empty.txt`    | ❌ División por cero porque el archivo está vacío (`ZeroDivisionError`) | `File is empty.`                             |
| `python cli_reader.py missing.txt`  | ❌ El archivo no existe (`FileNotFoundError`)                         | `File not found. Please check the filename.` |
| `python cli_reader.py`              | ❌ Argumento faltante (`IndexError`)                                  | `Usage: python average_reader.py <filename>` |

---

{Check It!|assessment}(code-output-compare-2639547540)
