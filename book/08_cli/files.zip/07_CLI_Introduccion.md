# Ejecutando Archivos Python (CLI)

## Objetivos de Aprendizaje

- ✅ Aprender qué es la Interfaz de Línea de Comandos.
- ✅ Aprender a ejecutar scripts de Python desde la línea de comandos.
- ✅ Comprender cómo pasar argumentos a un script.
- ✅ Explorar mejores prácticas para ejecutar scripts eficientemente.

---

## ¿Qué es la Línea de Comandos (CLI)?

La **Interfaz de Línea de Comandos (CLI)** permite a los usuarios ejecutar scripts de Python escribiendo comandos en una terminal o símbolo del sistema.

---

## 1. Ejecutando un Script de Python

Para ejecutar un archivo de Python, navega a su directorio en la terminal y usa:

```sh
python3 script.py
```

Esto ejecuta `script.py` usando Python.

### Ejemplo de Script (`hola.py`):

```python
print("¡Hola, Mundo!")
```

### Ejecutándolo en CLI:

```sh
python3 hola.py
```

**Salida:**

```
¡Hola, Mundo!
```

|||important
Cuando ejecutamos un archivo de Python en Codio usamos `python3`. Esto es porque es más específico para las versiones más nuevas de `python`. Sin embargo, dependiendo del sistema, `python3` puede no ser un alias válido, en cuyo caso puedes intentar solo `python`.
|||

---

## 2. Pasando Argumentos a un Script de Python

Los scripts de Python pueden aceptar argumentos de línea de comandos usando el módulo `sys`:

### Ejemplo de Script (`saludar.py`):

```python
import sys  # Profundizaremos en esto después

if len(sys.argv) > 1:
    print(f"¡Hola, {sys.argv[1]}!")
else:
    print("¡Hola, usuario!")
```

### Ejecutar con un argumento:

```sh
python3 saludar.py Alicia
```

**Salida:**

```sh
¡Hola, Alicia!
```

- `sys.argv[0]` es el nombre del script.
- `sys.argv[1]` es el primer argumento.

---

## Pregunta

En **`run_cli.txt`**, escribirás el comando para **ejecutar un script de Python** llamado **`run_cli_test.py`** con las siguientes **entradas de línea de comandos**:

- `Hello`
- `1234`
- `12.34`

---

### Importante — Requisito de Formato de Prueba

El caso de prueba espera un **formato de archivo específico**.
Para asegurar que la prueba se ejecute correctamente, incluye la siguiente línea **antes** de tu comando en `run_cli.txt`:

```plaintext
#!/bin/sh
```

Esta línea especifica que los comandos en el archivo deben ejecutarse usando el **shell de Unix**.

---

{Check It!|assessment}(code-output-compare-2296126788)
